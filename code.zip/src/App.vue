<template>
  <v-app id="inspire">
    <v-app-bar app>
      <v-toolbar-title>
        <img class="logoImg" :src="require(`@/assets/${'i3dcons.png'}`)" alt="">
      </v-toolbar-title>
    </v-app-bar>

    <v-main class="indigo lighten-5">
      <div class="headerArea">
        <div class="headerAreaContainer">
          <h1>I3Dcons, 3D icons for your next project</h1>
          <p>Free high qualitity 3D icons for your website or design project</p>
          <div class="headerAreaButtons">
            <a href="#icons" style="textDecoration: none"><v-btn color="indigo" style="color: #ffffff" elevation="2">Browse icons</v-btn></a>
            <v-btn color="indigo" style="color: #ffffff" elevation="2">Download all</v-btn>
          </div>
        </div>
        <div class="headerAreaContainer">
          <img class="headerImg" :src="require(`@/assets/${'facebookIcon.png'}`)" alt="">
        </div>
      </div>
      <v-container id="icons">
        <v-row>
          <template v-for="n in numberOfSets.length">
            <v-col :key="n" class="mt-2" cols="12">
              <strong>{{numberOfSets[n - 1][0]}}</strong>
              <v-btn
                icon
                fab
                dark
                small
                absolute
                right
                @click="addItemToSet(n - 1)"
              >
                <v-icon color="grey">mdi-download-multiple</v-icon>
              </v-btn>
            </v-col>

            <v-col
              v-for="j in numberOfSets[n - 1].length - 1"
              :key="`${n}${j}`"
              cols="6"
              md="2"
            >
              <v-sheet
                height="150"
                elevation="2"
                width="150"
                :style="{ background: numberOfSets[n - 1][j - 1] }"
                color="indigo lighten-5"
                rounded
                class="iconImgContainer"
                @click="openDownloadDialog([numberOfSets[n - 1][j], numberOfSets[n - 1][0]])"
              >
              <img class="iconImg" :src="require(`@/assets/${numberOfSets[n - 1][j]}`)" alt="">
              </v-sheet>
            </v-col>
          </template>
        </v-row>
      </v-container>
    </v-main>
    <v-footer
    dark
    padless
  >
    <v-card
      flat
      tile
      class="indigo lighten-1 white--text text-center"
      style="width: 100vw"
    >
      <v-card-text>
        <v-btn
          v-for="icon in icons"
          :key="icon"
          class="mx-4 white--text"
          icon
        >
          <v-icon size="24px">
            {{ icon }}
          </v-icon>
        </v-btn>
      </v-card-text>

      <v-card-text class="white--text pt-0">
        This is a school project for educational purposes only. In fact, we do not provide any services.
      </v-card-text>

      <v-divider></v-divider>

      <v-card-text class="white--text">
        {{ new Date().getFullYear() }} — <strong>I3Dcons</strong>
      </v-card-text>
    </v-card>
  </v-footer>
  <component :is="dialog" @closeButton="closeButton" v-bind="{ imgUrl: currentImg, category: currentCategory }"></component>
  </v-app>
</template>

<script>
import DownloadDialog from "./components/downloadWindow.vue";
export default {
  data() {
    return {
      numberOfSets: [["social media","facebookIcon.png", "instagramIcon.png","facebookIcon.png", "instagramIcon.png"], ["controls","facebookIcon.png", "instagramIcon.png","facebookIcon.png"], ["shoping","facebookIcon.png", "instagramIcon.png","facebookIcon.png","facebookIcon.png", "instagramIcon.png","facebookIcon.png", "instagramIcon.png","facebookIcon.png", "instagramIcon.png","facebookIcon.png", "instagramIcon.png"]],
      direction: "bottom",
      fab: false,
      fling: false,
      hover: true,
      tabs: null,
      top: false,
      right: true,
      bottom: false,
      left: false,
      transition: "slide-y-reverse-transition",
      dialog: "",
      currentImg: "",
      currentCategory: "",
      DownloadDialog: DownloadDialog,
      icons: [
        'mdi-facebook',
        'mdi-instagram',
      ],
    };
  },
  methods: {
    closeButton(){
      this.dialog = "";
    },

    openDownloadDialog(params){
      this.currentImg = params[0];
      this.currentCategory = params[1];
      this.dialog = DownloadDialog;
    }
  },
  watch: {
    top(val) {
      this.bottom = !val;
    },
    right(val) {
      this.left = !val;
    },
    bottom(val) {
      this.top = !val;
    },
    left(val) {
      this.right = !val;
    },
  },
};
</script>

<style scoped>
.headerArea{
  display: flex;
}

.headerAreaContainer:nth-child(2){
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0;
}
.headerAreaContainer{
  width: 50vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-left: 20px;
}

.headerAreaButtons button{
  margin-right: 20px;
}

.iconImg{
  width: 100px;
}

.iconImgContainer{
  display: flex;
  justify-content: center;
  align-items: center;
}

.headerImg{
  width: 50%;
}

.col-6 {
    flex: 0 0 50%;
    max-width: 165px;
}

.logoImg{
  height: 50px;
}

@media (max-width: 735px) {
  .headerArea{
    flex-direction: column;
  }

  .headerAreaContainer{
    width: 100vw;
    height: 50vh;
  }
}
</style>