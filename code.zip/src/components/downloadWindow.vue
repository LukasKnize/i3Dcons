<template>
<div class="cardContainer">
<v-card
    class="mx-auto"
    max-width="344"
    outlined
  >
    <v-list-item three-line>
      <v-list-item-content>
        <div class="text-overline mb-4">
          {{category}}
        </div>
        <v-list-item-title class="text-h5 mb-1">
          Download Icon
        </v-list-item-title>
        <v-list-item-subtitle>Download icon from multiple different angles</v-list-item-subtitle>
      </v-list-item-content>

      <v-list-item-avatar
        tile
        size="80"
        color="grey"
        style="display: flex; justify-content: center; align-items: center"
      >
      <img :src="require(`@/assets/${imgUrl}`)" style="width: 60px" alt=""></v-list-item-avatar>
    </v-list-item>

    <v-card-actions>
      <v-btn
        rounded
        text
        color="indigo" 
        style="color: #ffffff"
      >
        Download
      </v-btn>
      <v-btn
        outlined
        rounded
        text
        @click="closeDialog()"
      >
        Close
      </v-btn>
    </v-card-actions>
  </v-card>
</div>
</template>

<script>
export default {
    props:{
        imgUrl: String,
        category: String
    },
    methods:{
        closeDialog(){
            this.$emit("closeButton");
        }
    }
}
</script>

<style scoped>
.cardContainer{
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: 3;
    background-color: rgba(0, 0, 0, 0.231);
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>
